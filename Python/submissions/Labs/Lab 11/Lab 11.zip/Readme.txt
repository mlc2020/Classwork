interpolation_data.dat is the test file for activity b of part 2
asdfasdf.dat is the test file for activity a of part 2